/*
Ivan Novasak
2024-08-28
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java file is for a web application that is for searching for flights.
It stores data concerning accessing the flight repository.
 */


package com.snhu.flightsearchapp.flightsearch.repository;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {
    List<Flight> findByOriginAndDestination(String origin, String destination);
}
