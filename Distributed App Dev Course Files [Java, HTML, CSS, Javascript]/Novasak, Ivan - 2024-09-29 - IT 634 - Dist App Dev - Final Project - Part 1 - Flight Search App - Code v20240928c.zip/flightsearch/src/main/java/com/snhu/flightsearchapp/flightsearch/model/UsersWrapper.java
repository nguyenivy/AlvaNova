/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching for flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the Users Wrapper class, which is part of the Model in Spring Framework model-view-controller.
 */

package com.snhu.flightsearchapp.flightsearch.model;

// Necessary imports
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "users")
public class UsersWrapper {

    // Instantiate a List called users that stores User objects
    private List<User> users;

    // Method to get the user from the users List
    @XmlElement(name = "user")
    public List<User> getUsers() {
        return users;
    }

    // Method to set users in the users List
    public void setUsers(List<User> users) {
        this.users = users;
    }
} // End of UsersWrapper class

