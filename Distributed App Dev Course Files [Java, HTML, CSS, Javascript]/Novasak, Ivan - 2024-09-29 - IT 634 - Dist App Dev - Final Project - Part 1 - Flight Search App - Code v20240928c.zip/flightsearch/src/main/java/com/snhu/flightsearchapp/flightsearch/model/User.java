/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching for flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the User class, which is part of the Model in the Model-View-Controller Spring Framework.
 */


package com.snhu.flightsearchapp.flightsearch.model;

// Necessary imports
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "user")
public class User {

    // Private fields to store the username and password
    private String username;
    private String password;

    // Default constructors
    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Method to get the username
    @XmlElement
    public String getUsername() {
        return username;
    }

    // Method to set the username
    public void setUsername(String username) {
        this.username = username;
    }

    // Method to get the password
    @XmlElement
    public String getPassword() {
        return password;
    }

    // Method to set the password
    public void setPassword(String password) {
        this.password = password;
    }
} // End of User class
