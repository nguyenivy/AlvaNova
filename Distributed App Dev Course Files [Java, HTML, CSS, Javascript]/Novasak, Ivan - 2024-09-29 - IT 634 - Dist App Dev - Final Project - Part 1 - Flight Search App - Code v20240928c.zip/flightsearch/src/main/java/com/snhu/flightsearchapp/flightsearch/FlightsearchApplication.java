/*
Ivan Novasak
2024-09-21
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java file is the main method for a web application that is for searching for flights.
 */

package com.snhu.flightsearchapp.flightsearch;

// Necessary imports
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightsearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightsearchApplication.class, args);
	}

}
