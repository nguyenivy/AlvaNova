/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching for flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the web controller.
 */


package com.snhu.flightsearchapp.flightsearch.controller;

// Necessary imports
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

    // Create a String method called index that returns the index.html page that is located in /resources/templates
    @GetMapping("/")
    public String index() {
        return "index";
    } // End of index method

} // End of WebController class

