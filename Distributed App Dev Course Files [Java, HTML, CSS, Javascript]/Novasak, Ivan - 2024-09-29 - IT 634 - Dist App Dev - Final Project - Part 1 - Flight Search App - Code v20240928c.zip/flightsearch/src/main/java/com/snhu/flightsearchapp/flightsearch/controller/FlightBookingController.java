/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java class file is for a web application that is for searching and booking flights.
It handles booking a flight for a specific user.
 */


package com.snhu.flightsearchapp.flightsearch.controller;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.FlightBooking;
import com.snhu.flightsearchapp.flightsearch.service.FlightBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flights")
public class FlightBookingController {

    @Autowired
    private FlightBookingService flightBookingService;

    // Method for booking a flight that takes in a username, flight number, the origin, and destination as parameters
    @PostMapping("/book")
    public String bookFlight(@RequestParam String username, @RequestParam String flightNumber, @RequestParam String origin, @RequestParam String destination) {
        flightBookingService.bookFlight(username, flightNumber, origin, destination);
        return "Flight booked successfully!"; // Display a message to the user upon a successful booking
    }

    // Method for getting all booking for a specific user that takes in the username as the parameter
    @GetMapping("/bookings")
    public List<FlightBooking> getBookingsForUser(@RequestParam String username) {
        return flightBookingService.getBookingsForUser(username); // Display that user's bookings from the list
    }

} // End of FlightBookingController class