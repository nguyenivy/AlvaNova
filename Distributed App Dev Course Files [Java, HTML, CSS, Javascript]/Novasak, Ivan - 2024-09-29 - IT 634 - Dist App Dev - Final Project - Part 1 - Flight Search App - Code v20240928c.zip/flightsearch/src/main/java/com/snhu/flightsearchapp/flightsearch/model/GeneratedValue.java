package com.snhu.flightsearchapp.flightsearch.model;

public @interface GeneratedValue {
}
