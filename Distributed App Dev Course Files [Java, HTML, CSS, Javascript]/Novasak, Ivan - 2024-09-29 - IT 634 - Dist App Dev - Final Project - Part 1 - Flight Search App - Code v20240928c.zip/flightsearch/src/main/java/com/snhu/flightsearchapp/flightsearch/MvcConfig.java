/*
Ivan Novasak
2024-09-22
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java file is for setting up the secure web page views.
 */

package com.snhu.flightsearchapp.flightsearch;

// Necessary imports
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

    // Methods to add view controllers for the /home page, a default page (/), a /hello greeting page, and the /login page
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/home").setViewName("home");
        registry.addViewController("/").setViewName("home");
        registry.addViewController("/hello").setViewName("hello");
        registry.addViewController("/login").setViewName("login");
    }

}