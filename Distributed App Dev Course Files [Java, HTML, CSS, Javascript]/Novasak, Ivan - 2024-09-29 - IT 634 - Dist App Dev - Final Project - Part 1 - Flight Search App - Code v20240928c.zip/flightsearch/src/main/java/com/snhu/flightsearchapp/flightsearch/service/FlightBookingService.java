/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching and booking flights.
It is for creating new flight bookings and finding a user's existing flight bookings
 */


package com.snhu.flightsearchapp.flightsearch.service;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.FlightBooking;
import com.snhu.flightsearchapp.flightsearch.repository.FlightBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightBookingService {

    @Autowired
    private FlightBookingRepository bookingRepository;

    // Method called bookFlight that takes in the username, flight number, origin, and destination as parameters
    public FlightBooking bookFlight(String username, String flightNumber, String origin, String destination) {

        // Instantiate a new FlightBooking object called booking and set the username, flight number, origin, and destination
        FlightBooking booking = new FlightBooking();
        booking.setUsername(username);
        booking.setFlightNumber(flightNumber);
        booking.setOrigin(origin);
        booking.setDestination(destination);
        return bookingRepository.save(booking); // Saving the booking
    }

    // Method to find a flight booking in the list based on a specified username
    public List<FlightBooking> getBookingsForUser(String username) {
        return bookingRepository.findByUsername(username);
    }

} // End of FlightBookingService class
