/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java file is for a web application that is for searching for flights.
It is the controller required for Spring framework. This file contains method for displaying & searching for flights.
 */


package com.snhu.flightsearchapp.flightsearch.controller;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.Flight;
import com.snhu.flightsearchapp.flightsearch.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List; // Needed later

@RestController
public class FlightController {

    @Autowired
    private FlightService flightService;

    // Method to get all flights from the list
    @GetMapping("/flights")
    public List<Flight> getAllFlights() {
        return flightService.getAllFlights();
    }

    // Method to search for all flights in the list based on the parameters origin and destination
    @GetMapping("/flights/search")
    public List<Flight> searchFlights(@RequestParam String origin, @RequestParam String destination) {
        return flightService.searchFlights(origin, destination);
    }
} // End of FlightController class
