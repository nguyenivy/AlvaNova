/*
Ivan Novasak
2024-08-28
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java file is for a web application that is for searching for flights.
It is the Spring Boot service for searching for flights.
 */


package com.snhu.flightsearchapp.flightsearch.service;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.Flight;
import com.snhu.flightsearchapp.flightsearch.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List; // Needed later for lists

@Service
public class FlightService {

    @Autowired
    private FlightRepository flightRepository;

    // Method that searches for flights in a List in the repository given the origin and destination as parameters
    public List<Flight> searchFlights(String origin, String destination) {
        return flightRepository.findByOriginAndDestination(origin, destination);
    }

    // Method that lists all flights in the repository
    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }
}
