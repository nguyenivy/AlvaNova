/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching and booking flights.
It is for keeping a repository of flight bookings for searching a list based on the username
 */


package com.snhu.flightsearchapp.flightsearch.repository;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.FlightBooking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FlightBookingRepository extends JpaRepository<FlightBooking, Long> {
    List<FlightBooking> findByUsername(String username);
}
