/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching for flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the User Service class, which handles registration and authentication of the users.
 */

package com.snhu.flightsearchapp.flightsearch.service;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.User;
import org.springframework.stereotype.Service;
import jakarta.xml.bind.JAXBException;
import java.util.List;

@Service
public class UserService {

    // Method to authenticate the users via username and password parameters that match in the users List
    public boolean authenticate(String username, String password) throws JAXBException {
        List<User> users = XMLUtils.getUsers();
        return users.stream()
                .anyMatch(user -> user.getUsername().equals(username) && user.getPassword().equals(password));
    }

    // Method that registers new users in the List only if the username does not exist
    public boolean register(String username, String password) throws JAXBException {
        List<User> users = XMLUtils.getUsers();

        // Check if the user already exists
        boolean userExists = users.stream()
                .anyMatch(user -> user.getUsername().equals(username));

        if (userExists) {
            return false; // User already exists
        }

        // Adds the new user
        users.add(new User(username, password));
        XMLUtils.saveUsers(users);
        return true;
    }
} // End of UserService class
