/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching and booking flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the XML utilities class, which handles
writing to the XML file that stores the various usernames and their passwords.
 */

package com.snhu.flightsearchapp.flightsearch.model;

// Necessary imports
import java.io.File;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import java.util.List;
import java.util.ArrayList;

public class XMLUtils {

    // Instantiate a private static variable called XML_FILE that opens the users.xml file
    private static final String XML_FILE = "users.xml";

    // Method to get the users from the file, if it exists that returns a new ArrayList if it exists
    public static List<User> getUsers() throws JAXBException {
        File file = new File(XML_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        JAXBContext context = JAXBContext.newInstance(UsersWrapper.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        UsersWrapper wrapper = (UsersWrapper) unmarshaller.unmarshal(file);
        return wrapper.getUsers();
    }

    // Marshalling
    public static void saveUsers(List<User> users) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(UsersWrapper.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        UsersWrapper wrapper = new UsersWrapper();
        wrapper.setUsers(users);

        marshaller.marshal(wrapper, new File(XML_FILE));
    }
} // End of XMLUtils class
