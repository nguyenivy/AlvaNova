/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
This file is part of a Java Spring web application that authenticates users with a username and password for searching for flights.
It stores the usernames and their passwords in a local XML file and checks for validity.
It also allows registration of new users.
This file is the user controller.
 */

package com.snhu.flightsearchapp.flightsearch.controller;

// Necessary imports
import com.snhu.flightsearchapp.flightsearch.model.User;
import com.snhu.flightsearchapp.flightsearch.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    // Private object called UserService
    @Autowired
    private UserService userService;

    // Method to authenticate the user and display a message saying success or unauthorised
    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestBody User user) {
        try {
            boolean authenticated = userService.authenticate(user.getUsername(), user.getPassword());
            if (authenticated) {
                return ResponseEntity.ok("Authentication successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage()); // Display an error message if there was an internal server error
        }
    }

    // Method to register a new user or display a message if that user already exists
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        try {
            boolean registered = userService.register(user.getUsername(), user.getPassword());
            if (registered) {
                return ResponseEntity.ok("Registration successful"); // Display a message to the user indicating successful registration
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists"); // Display a message to the user indicating that this user already exists
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage()); // Display an error message if there was an internal server error
        }
    }
} // End of UserController class
