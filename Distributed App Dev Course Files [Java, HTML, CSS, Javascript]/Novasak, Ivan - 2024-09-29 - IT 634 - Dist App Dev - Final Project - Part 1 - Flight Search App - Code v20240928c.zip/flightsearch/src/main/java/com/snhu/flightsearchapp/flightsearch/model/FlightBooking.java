/*
Ivan Novasak
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search App
This Java class file is for a web application that is for searching for flights.
It stores attributes about a flight booking.
 */


package com.snhu.flightsearchapp.flightsearch.model;

// Necessary import
import jakarta.persistence.*;

@Entity
public class FlightBooking {

    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY) <-- Is this needed? Getting a compiler error due to 'strategy' mention
    private Long id;

    private String username;

    private String flightNumber;
    private String origin;
    private String destination;

    // Accessors and mutators
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

} // End of FlightBooking class
