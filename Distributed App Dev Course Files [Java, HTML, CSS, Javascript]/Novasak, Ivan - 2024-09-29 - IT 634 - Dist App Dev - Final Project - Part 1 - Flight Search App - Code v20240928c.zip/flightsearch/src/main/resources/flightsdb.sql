/*
Novasak, Ivan
2024-09-26
Southern New Hampshire University
IT 634: Distributed Application Development
Flights SQL Database Code
*/

--  Drop (if exists), Create (if not exist), and Use the database.

DROP DATABASE IF EXISTS Flights_DB;
CREATE DATABASE IF NOT EXISTS Flights_DB;
USE Flights_DB;

-- Create a Flights table

CREATE TABLE IF NOT EXISTS Flights (
	flightNr VARCHAR(16) NOT NULL,
	airline VARCHAR(100) NOT NULL,
        origin VARCHAR(100) NOT NULL,
        destination VARCHAR(100) NOT NULL,
        departureDate DATE NOT NULL,
        departureTime CHAR(5) NOT NULL,
        arrivalDate DATE NOT NULL,
        arrivalTime CHAR(5) NOT NULL,
        nrTravellers INT NOT NULL,
        price DOUBLE NOT NULL,
	
    CONSTRAINT Flights_PK PRIMARY KEY (flightNr)
);

-- Insert dummy data into the Flights table

INSERT INTO Flights (flightNr, airline, origin, destination, departureDate, departureTime, arrivalDate, arrivalTime, nrTravellers, price)
VALUES
('JZA8858', 'Jazz', 'Philadelphia', 'Montreal', '2024-08-18', '10:00', '2024-08-18', '11:30', 2, 256),
('PDT5717', 'Piedmont', 'Philadelphia', 'Montreal', '2024-08-19', '11:00', '2024-08-18', '12:40',  1, 200),
('JZA7112', 'Jazz', 'Ottawa', 'Montreal', '2024-09-03', '10:13', '2024-09-03', '10:42',  3, 300)
;
