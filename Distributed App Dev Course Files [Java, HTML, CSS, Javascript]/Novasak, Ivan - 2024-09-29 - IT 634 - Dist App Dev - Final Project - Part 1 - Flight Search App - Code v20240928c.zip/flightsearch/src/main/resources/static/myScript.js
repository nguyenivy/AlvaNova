/*
Novasak, Ivan
2024-08-24
Southern New Hampshire University
IT 634: Distributed Application Development
Flight Search Web App

This file is a JavaScript file for processing entered data from a web page as
part of an app that searches for flights.
It is to acquire the traveller's origin city, destination city,
departure date, and number of travellers and display a listing of available flights.
*/

// Event listener for the submit button from the HTML page
document.addEventListener('DOMContentLoaded', function() {

    // Define variables form and resultsDiv for data to be saved into
    const form = document.getElementById('flightSearchForm');
    const resultsDiv = document.getElementById('searchResults');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Collect form data

        // Define a variable called formData that instantiates a new FormData object that takes in form as its argument
        const formData = new FormData(form);

        // Define variables called origin, destination, travelDate, and nrTravellers that get the respective elements from the HTML page
        const origin = formData.get('origin');
        const destination = formData.get('destination');
        const travelDate = formData.get('travelDate');
        const nrTravellers = formData.get('nrTravellers');

        // Define a variable called fakeFlights housing some sample flight numbers and prices for displaying working code
        const fakeFlights = [
            { flightNumber: 'JZA8858', price: 256 },
            { flightNumber: 'PDT5717', price: 200 },
            { flightNumber: 'JIA5112', price: 300 }
        ];
        // Sample flight numbers sourced from <https://www.flightaware.com/live/findflight/KPHL/CYUL>

        // Generate the results HTML
        let resultsHtml = `
            <h2>Search Results:</h2>
            <p><strong>Origin:</strong> ${origin}</p>
            <p><strong>Destination:</strong> ${destination}</p>
            <p><strong>Date of Travel:</strong> ${travelDate}</p>
            <p><strong>Number of Travellers:</strong> ${nrTravellers}</p>
            <h3>Available Flights:</h3>
            <ul>
        `;

        // Add fake flight options and display a listing of each
        fakeFlights.forEach(flight => {
            resultsHtml += `
                <li>Flight ${flight.flightNumber}: ${origin} to ${destination} on ${travelDate} - $${flight.price}</li>
            `;
        });

        resultsHtml += '</ul>';

        // Display the results
        resultsDiv.innerHTML = resultsHtml;
    });
});
