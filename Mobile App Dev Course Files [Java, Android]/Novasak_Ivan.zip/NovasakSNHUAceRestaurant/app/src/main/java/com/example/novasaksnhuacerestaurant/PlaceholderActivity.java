package com.example.novasaksnhuacerestaurant;

/*
Novasak, Ivan
2025-01-29
IT 633
This Java file is part of an Android app for booking reservations to Ace Restaurant.
It is a Placeholder Activity for features not yet made.
 */

// Necessary imports

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PlaceholderActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeholder);

        // Retrieve the option name passed from MainActivity
        String option = getIntent().getStringExtra("option");

        // Update the TextView with the option name
        TextView placeholderMessage = findViewById(R.id.placeholder_message);
        // Display the message to the user that clicked an option not yet developed
        placeholderMessage.setText(option + " - To Be Developed Later");
    }
}
