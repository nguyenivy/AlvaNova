package com.example.novasaksnhuacerestaurant;

/*
Novasak, Ivan
2025-02-07
IT 633
This Java file is part of an Android app for booking reservations to Ace Restaurant.
It is the Main Activity.

2025-02-07 update: added icons and handling for icon taps

 */

// Necessary imports
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private String[] menuOptions = {
            "Menu", "Online Ordering", "Calorie Counter", "Catering",
            "Beverage Mixer", "Reservations", "Get Directions", "About Us", "Contact Us"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView menuList = findViewById(R.id.menu_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, menuOptions);
        menuList.setAdapter(adapter);

        // Handle text menu clicks
        menuList.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> handleNavigation(menuOptions[position]));

        // Handle icon clicks
        findViewById(R.id.icon_menu).setOnClickListener(v -> handleNavigation("Menu"));
        findViewById(R.id.icon_order).setOnClickListener(v -> handleNavigation("Order"));
        findViewById(R.id.icon_calories).setOnClickListener(v -> handleNavigation("Calories"));
        findViewById(R.id.icon_catering).setOnClickListener(v -> handleNavigation("Catering"));
        findViewById(R.id.icon_mixer).setOnClickListener(v -> handleNavigation("Mixer"));
        findViewById(R.id.icon_reserve).setOnClickListener(v -> handleNavigation("Reservations"));
        findViewById(R.id.icon_locate).setOnClickListener(v -> handleNavigation("Get Directions"));
        findViewById(R.id.icon_about).setOnClickListener(v -> handleNavigation("About Us"));
        findViewById(R.id.icon_contact).setOnClickListener(v -> handleNavigation("Contact Us"));
    }

    private void handleNavigation(String option) {
        Intent intent;
        switch (option) {
            case "Reservations":
                intent = new Intent(this, ReservationsActivity.class);
                break;
            case "Get Directions":
                intent = new Intent(this, DirectionsActivity.class);
                break;
            default:
                intent = new Intent(this, PlaceholderActivity.class);
                intent.putExtra("option", option);
                break;
        }
        startActivity(intent);
    }
}
