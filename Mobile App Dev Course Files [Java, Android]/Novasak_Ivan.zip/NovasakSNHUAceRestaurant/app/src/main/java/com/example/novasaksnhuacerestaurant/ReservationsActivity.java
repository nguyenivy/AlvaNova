package com.example.novasaksnhuacerestaurant;

/*
Novasak, Ivan
2025-01-29
IT 633
This Java file is part of an Android app for booking reservations to Ace Restaurant.
It is the Reservations Activity for handling bookings.
 */

// Necessary imports

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class ReservationsActivity extends AppCompatActivity {
    private TextView dateInput, timeInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservations);

        dateInput = findViewById(R.id.date_input);
        timeInput = findViewById(R.id.time_input);
        EditText peopleInput = findViewById(R.id.people_input);
        EditText nameInput = findViewById(R.id.name_input);
        EditText phoneInput = findViewById(R.id.phone_input);
        EditText emailInput = findViewById(R.id.email_input);
        Button reserveButton = findViewById(R.id.reserve_button);

        // Open DatePickerDialog on date field click
        dateInput.setOnClickListener(v -> showDatePicker());

        // Open TimePickerDialog on time field click
        timeInput.setOnClickListener(v -> showTimePicker());

        // Handle reservation submission
        reserveButton.setOnClickListener(v -> {
            String reservationDetails = "Reservation for " + nameInput.getText().toString() +
                    " on " + dateInput.getText().toString() +
                    " at " + timeInput.getText().toString();
            Toast.makeText(ReservationsActivity.this, reservationDetails, Toast.LENGTH_LONG).show();
        });
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
            dateInput.setText(selectedDate);
        }, year, month, day);

        datePickerDialog.show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            String selectedTime = String.format("%02d:%02d", selectedHour, selectedMinute);
            timeInput.setText(selectedTime);
        }, hour, minute, true);

        timePickerDialog.show();
    }
}
