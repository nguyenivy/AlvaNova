package com.example.novasaksnhuacerestaurant;

/*
Novasak, Ivan
2025-01-29
IT 633
This Java file is part of an Android app for booking reservations to Ace Restaurant.
It is the Directions Activity.
 */

// Necessary imports

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DirectionsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directions);

        // Text field for the user to enter their starting address
        EditText startLocationInput = findViewById(R.id.start_location_input);
        // Submit button for the user to confirm
        Button getDirectionsButton = findViewById(R.id.get_directions_button);

        // Listen for the user's tap of the button to acquire the entered address, then simulate
        getDirectionsButton.setOnClickListener(v -> {
            // Simulate retrieving directions
            String message = "Getting directions from " + startLocationInput.getText().toString();
            Toast.makeText(DirectionsActivity.this, message, Toast.LENGTH_LONG).show();
        });
    }
}
